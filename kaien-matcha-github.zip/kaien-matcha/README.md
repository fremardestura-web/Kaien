# KAIEN Matcha Recipe Journal

A stylish, responsive HTML/CSS/JavaScript matcha recipe website designed for GitHub Pages.

## Files
- `index.html` — page structure and content
- `style.css` — responsive visual design
- `script.js` — recipe data, filtering, recipe modal and mobile menu

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Commit the files.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select `main` and `/root`, then save.

## Image note
The original SOKO menu URL supplied for the reference could not be fetched reliably during development. The featured visual therefore uses a publicly indexed SOKO Cake & Brunch matcha image from a Behance project as a visual reference. Replace the image URL in `index.html` if you have permission to use the exact SOKO menu image.

The recipes on KAIEN are written as home-recipe interpretations based on the drink names and flavor profiles. They are not presented as SOKO's proprietary recipes.
